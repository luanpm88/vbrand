-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2021 at 07:59 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brand2`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE `aboutus` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyword` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`id`, `title`, `description`, `content`, `keyword`, `photo`, `created`, `created_at`, `updated_at`) VALUES
(1, 'Giới thiệu', 'chuyên trang giới thiệu về Vũ Hoàng Land', 'Hiệp định thương mại tự do EVFTA ký kết vào tháng 6/2020&nbsp;', 'Vu hoang land', '5-yeu-to-tang-truong-bds-binh-duong.jpeg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyword` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `home` int(11) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `slug`, `description`, `content`, `keyword`, `created`, `status`, `del`, `created_at`, `updated_at`, `home`, `parent`) VALUES
(2, 'Đồ thể thao', 'do-the-thao', 'Đồ thể thao', 'Đồ thể thao', 'Đồ thể thao', NULL, 1, NULL, '2020-08-11 20:06:10', '2020-09-11 21:15:34', 1, 0),
(3, 'Máy tính & phụ kiện', 'may-tinh-phu-kien', 'Máy tính & phụ kiện', 'Máy tính & phụ kiện', 'Máy tính & phụ kiện', NULL, 1, NULL, '2020-08-19 20:29:22', '2020-09-11 21:15:56', 1, 0),
(4, 'Đồ văn phòng', 'do-van-phng', 'Cái mùi', 'Cái mùi', 'Cái mùi', NULL, 1, NULL, '2020-08-19 20:29:46', '2020-09-11 21:16:32', 1, 0),
(5, 'sản phẩm tổng hợp', 'san-pham-tong-hop', 'Cái Gon', 'Cái Gon', 'Cái Gon', NULL, 1, NULL, '2020-08-19 20:29:55', '2020-09-11 21:16:48', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(10) UNSIGNED NOT NULL,
  `site_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_keyword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_hotline` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_flogo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_slogon_vn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_slogon_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_address_vn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_address_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_companyname_vn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_companyname_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `site_name`, `site_keyword`, `site_description`, `site_hotline`, `site_logo`, `site_flogo`, `site_email`, `site_slogon_vn`, `site_slogon_en`, `site_address_vn`, `site_address_en`, `site_companyname_vn`, `site_companyname_en`, `created_at`, `updated_at`) VALUES
(1, 'cong nghe', 'thanh cong', 'dien giai ngan', 'hotline', NULL, NULL, 'email', 'cong ghe co ban moi', 'cong nghe co bán ne ban', '777 cộng hòa, tân bình, HCM', '777 cộng hòa, tân bình, HCM', '777 cộng hòa, tân bình, HCM', '777 cộng hòa, tân bình, HCM', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desription` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `phone` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `post_id`, `user_id`, `name`, `tel`, `email`, `file`, `desription`, `created`, `status`, `del`, `created_at`, `updated_at`, `phone`) VALUES
(1, NULL, NULL, 'thanh cong', NULL, 'huy3@natrapha.com', NULL, 'thanh cong roi ban oi', NULL, NULL, NULL, '2020-09-24 17:23:10', '2020-09-24 17:23:10', '083806826812'),
(2, NULL, NULL, 'thanh cong', NULL, 'huy8@natrapha.com', NULL, 'thanh cong roi ban oi', NULL, NULL, NULL, '2020-09-24 17:24:19', '2020-09-24 17:24:19', '083806826812'),
(3, NULL, NULL, 'hoang hai nam', NULL, 'hoalamreal@gmail.com', NULL, 'thanh cong roi ban oi', NULL, NULL, NULL, '2020-09-24 17:27:30', '2020-09-24 17:27:30', '08380682681');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(20, '2014_10_12_000000_create_users_table', 7),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_08_02_040458_create_posts_table', 2),
(5, '2020_08_02_040540_create_category_table', 2),
(16, '2020_08_02_040829_create_video_table', 4),
(15, '2020_08_02_040614_create_photo_table', 4),
(8, '2020_08_02_040932_create_feedback_table', 2),
(14, '2020_08_07_170304_create_products_table', 3),
(10, '2020_08_11_103959_create_orders_table', 2),
(11, '2020_08_11_104021_create_orders_detail_table', 2),
(12, '2020_08_11_105109_create_comments_table', 2),
(17, '2020_09_03_023631_add_google_id_column', 5),
(18, '2020_09_16_034258_create_payment_table', 6),
(19, '2020_09_30_033929_create_config_table', 6),
(21, '2016_06_01_000001_create_oauth_auth_codes_table', 8),
(22, '2016_06_01_000002_create_oauth_access_tokens_table', 8),
(23, '2016_06_01_000003_create_oauth_refresh_tokens_table', 8),
(24, '2016_06_01_000004_create_oauth_clients_table', 8),
(25, '2016_06_01_000005_create_oauth_personal_access_clients_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('2c82b398a516518ac8b0d8b852eaf4354f9f3be206d416a1533b1ab55b2f0184208787ae18278292', 6, 1, 'MyApp', '[]', 0, '2020-09-30 03:21:53', '2020-09-30 03:21:53', '2021-09-30 10:21:53'),
('4aec1495f68163118163f7be188c84ea2ee11d89d037d40e641ad6c220f768b5befcea5283160986', 6, 1, 'MyApp', '[]', 0, '2020-09-30 02:09:28', '2020-09-30 02:09:28', '2021-09-30 09:09:28'),
('d4ab7ca0f87e62a73f67819f4880a4aa0bc7f137bd2feb511bb89a30927988a8595e875ef826b792', 6, 1, 'MyApp', '[]', 0, '2020-09-30 03:22:29', '2020-09-30 03:22:29', '2021-09-30 10:22:29'),
('fec651d11603f3eaa764bc186d4189a310aafd8fe8c6e25a86556135d3be650729b1d2879350cfbe', 6, 1, 'MyApp', '[]', 0, '2020-09-30 03:22:49', '2020-09-30 03:22:49', '2021-09-30 10:22:49');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', '4iLuLtGIIKNY5lpjZpK5ipUhNvCieSZa62UkVwB3', NULL, 'http://localhost', 1, 0, 0, '2020-09-30 01:43:55', '2020-09-30 01:43:55'),
(2, NULL, 'Laravel Password Grant Client', 'pUnegrvjCoim9oXxLdBe6gmyowtJFm0hfHr44WvT', 'users', 'http://localhost', 0, 1, 0, '2020-09-30 01:43:55', '2020-09-30 01:43:55');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-09-30 01:43:55', '2020-09-30 01:43:55');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `currency` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paystatus` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `datepay` date DEFAULT NULL,
  `recept_name` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recept_phone` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recept_address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recept_email` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recept_note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendship` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendcreated` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendstatus` int(11) DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payerId` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `paymentId` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_id` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `payment`, `total`, `currency`, `paystatus`, `datepay`, `recept_name`, `recept_phone`, `recept_address`, `recept_email`, `recept_note`, `shipping`, `sendship`, `sendcreated`, `sendstatus`, `note`, `created_at`, `updated_at`, `payerId`, `paymentId`, `invoice_id`) VALUES
(49, 6, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'hoalamreal@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-21 20:52:49', '2020-09-21 20:52:49', NULL, NULL, NULL),
(45, 6, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'hoalamreal@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-21 20:27:18', '2020-09-21 20:27:18', NULL, NULL, NULL),
(46, 6, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'hoalamreal@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-21 20:27:36', '2020-09-21 20:27:36', NULL, NULL, NULL),
(47, 6, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'hoalamreal@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-21 20:27:44', '2020-09-21 20:27:44', NULL, NULL, NULL),
(48, 6, NULL, 3, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-21 20:29:31', '2020-09-21 23:49:51', NULL, NULL, NULL),
(50, 11, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'huy11@natrapha.com', NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-24 03:01:37', '2020-09-24 03:01:37', NULL, NULL, NULL),
(37, 2, NULL, 3, 'USD', NULL, NULL, 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha', '[\"viettel\",\"sms\"]', NULL, NULL, NULL, NULL, '2020-09-16 19:26:49', '2020-09-16 20:19:49', NULL, NULL, NULL),
(38, 2, NULL, 3, 'USD', NULL, NULL, 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha', '[\"giaohangtietkiem\"]', NULL, NULL, NULL, NULL, '2020-09-16 20:22:49', '2020-09-16 20:23:51', NULL, NULL, NULL),
(39, 2, NULL, 7, 'USD', NULL, NULL, 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha', '[\"giaohangtietkiem\"]', NULL, NULL, NULL, NULL, '2020-09-16 20:24:55', '2020-09-16 20:28:29', NULL, NULL, NULL),
(40, 2, NULL, 3, 'USD', NULL, NULL, 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha', '[\"giaohangtietkiem\",\"sms\"]', NULL, NULL, NULL, NULL, '2020-09-16 20:30:59', '2020-09-16 20:31:14', NULL, NULL, NULL),
(41, 2, 'PayPal', 3, 'USD', 'paied', '2020-09-17', 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha', '[\"giaohangtietkiem\"]', NULL, NULL, NULL, NULL, '2020-09-16 20:47:01', '2020-09-16 20:47:47', 'N87LR7KDTS4ZS', 'PAYID-L5RNYQQ1VL26916GV913334J', NULL),
(42, 2, 'PayPal', 3, 'USD', 'paied', '2020-09-17', 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha', '[\"giaohangtietkiem\"]', NULL, NULL, NULL, NULL, '2020-09-16 21:31:17', '2020-09-16 21:31:59', 'N87LR7KDTS4ZS', 'PAYID-L5RONIQ29639698M85726104', NULL),
(43, 2, 'PayPal', 3, 'USD', 'paied', '2020-09-17', 'nguyen dinh huy', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha bạn', '[\"giaohangtietkiem\",\"sms\"]', NULL, NULL, NULL, NULL, '2020-09-16 23:58:18', '2020-09-16 23:59:11', 'N87LR7KDTS4ZS', 'PAYID-L5RQSHI1HM53422WS077334W', NULL),
(44, 6, 'PayPal', 3, 'USD', 'paied', '2020-09-17', 'nguyen hoang nam', '0904049522', '716/13 tân kỳ tân quý, bình hưng hòa, bình tân, hồ chí minh', 'canhoduclong@gmail.com', 'gửi trong giờ hành chánh cho tôi nha bạn', '[\"viettel\",\"giaohangtietkiem\"]', NULL, NULL, NULL, NULL, '2020-09-17 02:24:23', '2020-09-17 02:25:17', 'N87LR7KDTS4ZS', 'PAYID-L5RSWXA02C14357670386849', '5f632b59b1d47');

-- --------------------------------------------------------

--
-- Table structure for table `orders_detail`
--

CREATE TABLE `orders_detail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders_detail`
--

INSERT INTO `orders_detail` (`id`, `user_id`, `order_id`, `product_id`, `price`, `quantity`, `created_at`, `updated_at`, `currency`) VALUES
(1, 2, 10, 4, 750000, 4, '2020-09-07 10:57:11', '2020-09-07 10:57:11', 'USD'),
(2, 2, 11, 4, 750000, 4, '2020-09-07 10:57:59', '2020-09-07 10:57:59', 'USD'),
(3, 2, 12, 4, 750000, 4, '2020-09-07 11:00:27', '2020-09-07 11:00:27', 'USD'),
(4, 2, 13, 4, 750000, 4, '2020-09-07 11:15:43', '2020-09-07 11:15:43', 'USD'),
(5, 2, 14, 4, 750000, 4, '2020-09-07 11:33:29', '2020-09-07 11:33:29', 'USD'),
(6, 2, 14, 3, 650000, 1, '2020-09-07 11:33:29', '2020-09-07 11:33:29', 'USD'),
(7, 2, 15, 1, 20000, 5, '2020-09-10 05:12:45', '2020-09-10 05:12:45', 'USD'),
(8, 3, 16, 3, 650000, 1, '2020-09-10 05:18:19', '2020-09-10 05:18:19', 'USD'),
(9, 3, 16, 1, 20000, 1, '2020-09-10 05:18:19', '2020-09-10 05:18:19', 'USD'),
(10, 2, 17, 2, 23000, 1, '2020-09-11 21:14:07', '2020-09-11 21:14:07', 'USD'),
(11, 2, 18, 2, 23000, 1, '2020-09-11 21:21:03', '2020-09-11 21:21:03', 'USD'),
(12, 3, 19, 1, 20000, 1, '2020-09-11 21:24:25', '2020-09-11 21:24:25', 'USD'),
(13, 2, 20, 1, 20000, 1, '2020-09-11 21:27:25', '2020-09-11 21:27:25', 'USD'),
(14, 3, 21, 2, 23000, 1, '2020-09-13 20:02:44', '2020-09-13 20:02:44', 'USD'),
(15, 3, 22, 2, 23000, 1, '2020-09-14 00:53:06', '2020-09-14 00:53:06', 'USD'),
(16, 3, 23, 2, 23000, 1, '2020-09-14 02:05:00', '2020-09-14 02:05:00', 'USD'),
(17, 2, 24, 2, 23000, 1, '2020-09-15 19:37:53', '2020-09-15 19:37:53', 'USD'),
(18, 2, 24, 1, 20000, 1, '2020-09-15 19:37:53', '2020-09-15 19:37:53', 'USD'),
(19, 2, 25, 1, 20000, 1, '2020-09-15 19:52:18', '2020-09-15 19:52:18', 'USD'),
(20, 2, 26, 1, 20000, 1, '2020-09-15 19:53:23', '2020-09-15 19:53:23', 'USD'),
(21, 2, 26, 2, 23000, 1, '2020-09-15 19:53:23', '2020-09-15 19:53:23', 'USD'),
(22, 2, 27, 1, 20000, 1, '2020-09-15 20:09:20', '2020-09-15 20:09:20', 'USD'),
(23, 2, 27, 2, 23000, 1, '2020-09-15 20:09:20', '2020-09-15 20:09:20', 'USD'),
(24, 2, 28, 1, 20000, 1, '2020-09-15 20:12:29', '2020-09-15 20:12:29', 'USD'),
(25, 2, 28, 2, 23000, 1, '2020-09-15 20:12:29', '2020-09-15 20:12:29', 'USD'),
(26, 2, 29, 2, 4, 1, '2020-09-15 20:39:32', '2020-09-15 20:39:32', 'USD'),
(27, 2, 29, 1, 3, 1, '2020-09-15 20:39:32', '2020-09-15 20:39:32', 'USD'),
(28, 2, 30, 2, 4, 1, '2020-09-15 21:20:46', '2020-09-15 21:20:46', 'USD'),
(29, 2, 30, 1, 3, 1, '2020-09-15 21:20:46', '2020-09-15 21:20:46', 'USD'),
(30, 2, 31, 2, 4, 1, '2020-09-15 21:23:22', '2020-09-15 21:23:22', 'USD'),
(31, 2, 31, 1, 3, 1, '2020-09-15 21:23:22', '2020-09-15 21:23:22', 'USD'),
(32, 2, 32, 1, 3, 1, '2020-09-15 21:32:22', '2020-09-15 21:32:22', 'USD'),
(33, 2, 33, 2, 4, 1, '2020-09-16 00:32:37', '2020-09-16 00:32:37', 'USD'),
(34, 2, 33, 1, 3, 1, '2020-09-16 00:32:37', '2020-09-16 00:32:37', 'USD'),
(35, 2, 34, 1, 3, 1, '2020-09-16 00:32:46', '2020-09-16 00:32:46', 'USD'),
(36, 2, 35, 2, 4, 1, '2020-09-16 01:07:28', '2020-09-16 01:07:28', 'USD'),
(37, 2, 36, 1, 3, 1, '2020-09-16 03:02:29', '2020-09-16 03:02:29', 'USD'),
(38, 2, 36, 2, 4, 1, '2020-09-16 03:02:29', '2020-09-16 03:02:29', 'USD'),
(39, 2, 37, 1, 3, 1, '2020-09-16 19:26:49', '2020-09-16 19:26:49', 'USD'),
(40, 2, 38, 1, 3, 1, '2020-09-16 20:22:49', '2020-09-16 20:22:49', 'USD'),
(41, 2, 39, 1, 3, 1, '2020-09-16 20:24:55', '2020-09-16 20:24:55', 'USD'),
(42, 2, 39, 2, 4, 1, '2020-09-16 20:24:55', '2020-09-16 20:24:55', 'USD'),
(43, 2, 40, 1, 3, 1, '2020-09-16 20:30:59', '2020-09-16 20:30:59', 'USD'),
(44, 2, 41, 1, 3, 1, '2020-09-16 20:47:01', '2020-09-16 20:47:01', 'USD'),
(45, 2, 42, 1, 3, 1, '2020-09-16 21:31:17', '2020-09-16 21:31:17', 'USD'),
(46, 2, 43, 1, 3, 1, '2020-09-16 23:58:18', '2020-09-16 23:58:18', 'USD'),
(47, 2, 44, 1, 3, 1, '2020-09-17 02:24:23', '2020-09-17 02:24:23', 'USD'),
(48, 6, 45, 1, 3, 1, '2020-09-21 20:27:18', '2020-09-21 20:27:18', 'USD'),
(49, 6, 46, 1, 3, 1, '2020-09-21 20:27:36', '2020-09-21 20:27:36', 'USD'),
(50, 6, 47, 1, 3, 1, '2020-09-21 20:27:44', '2020-09-21 20:27:44', 'USD'),
(51, 6, 48, 1, 3, 1, '2020-09-21 20:29:31', '2020-09-21 20:29:31', 'USD'),
(52, 6, 49, 1, 3, 1, '2020-09-21 20:52:49', '2020-09-21 20:52:49', 'USD'),
(53, 11, 50, 1, 3, 1, '2020-09-24 03:01:37', '2020-09-24 03:01:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('canhoduclong@gmail.com', '$2y$10$GYZ/cqsbz7l3xyUYeDEUbOhUUKeZsBYKygxzkf.pFCx/Oh6EPWxYW', '2020-09-18 00:59:33');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `transaction_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `currency_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE `photo` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `src` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `desription` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` tinyint(4) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyword` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `view` int(11) DEFAULT 1,
  `hot` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `description`, `content`, `keyword`, `created`, `status`, `photo`, `del`, `created_at`, `updated_at`, `view`, `hot`) VALUES
(26, 5, 2, 'SoftBank được bơm 45 tỷ USD trong 45 phút,  giấc mơ của Masayoshi Son thành hiện thực', 'softbank-duoc-bom-45-ty-usd-trong-45-phut-giac-mo-cua-masayoshi-son-thanh-hien-thuc', 'Không chỉ đồng ý bơm 45 tỷ USD trong 45 phút, Thái tử Ả rập sẽ biến giấc mơ của Masayoshi Son thành hiện thực', '<h2 class=\"knc-sapo\">Tỷ phú Masayoshi Son của SoftBank đang tiến gần hơn\r\n tới giấc mơ trở thành quỹ đầu tư lớn nhất trong lĩnh vực công nghệ khi \r\nThái tử Ả rập Xê út Mohammed bin Salman đang có kế hoạch chi tới 100 tỷ \r\nUSD cho công ty.</h2><div><p>Ở thời điểm hiện tại, Thái tử Salman đã là nhà đầu tư lớn nhất, đóng \r\ngóp một nửa số tiền mà Masayoshi Son quyên góp nhằm đưa tên tuổi Quỹ tầm\r\n nhìn SoftBank trở thành số một thế giới trong lĩnh vực đầu tư công \r\nnghệ. Tuy nhiên, số tiền có thể chưa dừng lại ở đó khi Thái tử Salman \r\nđang tiến hành cuộc truy quét tham nhũng ở Ả rập Xê út, động thái được \r\nmô tả là củng cố quyền lực của người sẽ trở thành Quốc vương của Vương \r\nquốc giàu dầu mỏ.</p><p>Khi quyền lực của Thái tử Salman lớn hơn, số \r\ntiền nhân vật này đổ cho Quỹ tầm nhìn SoftBank có thể tăng theo tỷ lệ \r\nthuận. Việc có nhiều tiền cũng khiến Softbank đầu tư mạnh dạn hơn mà \r\nkhông quá nặng nề với bài toán tìm doanh thu nhằm giảm gánh nặng. Cùng \r\nvới đó, người ta cũng chẳng còn nghi ngờ về sự bền vững trong các khoản \r\nđầu tư của Thái tử Salman.</p><p>Ông Mana Nakazora, trưởng phòng phân \r\ntích tín dụng của BNP Paribas SA, nhận định: “Ả rập Xê út có tiền để đầu\r\n tư, điều đó có nghĩa là khả năng tài trợ cho một quỹ tầm nhìn thứ 2, \r\nhoặc thứ ba. Sức ảnh hưởng lớn từ Thái tử Salman càng làm cho khả năng \r\nđó có thể trở thành hiện thực. Hiện tại, Ả rập Xê út đã chi 45 tỷ USD \r\ncho quỹ này, biến họ trở thành nhà đầu tư lớn nhất. Thỏa thuận khổng lồ \r\nđạt được trong cuộc họp kéo dài 45 phút giữa Masayoshi Son và Thái tử \r\nSalman.</p><p>Với Quỹ tầm nhìn, nhà sáng lập SoftBank đang tìm kiếm sự \r\ngia tăng ảnh hưởng trong vai trò một nhà đầu tư công nghệ, đánh cược \r\ntương lai vào trí tuệ nhân tạo, thiết bị kết nối hay xa hơn là sự kết \r\nhợp giữa máy tính với con người. Quỹ này đã huy động được 93 tỷ USD ở \r\nthời điểm hiện tại. Ngoài tiền từ Ả rập Xê út, quỹ còn có 28 tỷ USD từ \r\nSoftBank và 20 tỷ USD từ các nhà đầu tư khác.</p><div class=\"VCSortableInPreviewMode active\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/2017/photo-1-1513042496220.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Thái tử Salman và nhà sáng lập SoftBank Masayoshi Son.\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/2017/photo-1-1513042496220.jpg\" id=\"img_a940d820-dedc-11e7-aad6-b357a4250db9\" alt=\"Không chỉ đồng ý bơm 45 tỷ USD trong 45 phút, Thái tử Ả rập sẽ biến giấc mơ của Masayoshi Son thành hiện thực? - Ảnh 1.\" title=\"Không chỉ đồng ý bơm 45 tỷ USD trong 45 phút, Thái tử Ả rập sẽ biến giấc mơ của Masayoshi Son thành hiện thực? - Ảnh 1.\" rel=\"lightbox\" type=\"photo\" style=\"max-width:100%;\" data-original=\"https://genk.mediacdn.vn/2017/photo-1-1513042496220.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Thái tử Salman và nhà sáng lập SoftBank Masayoshi Son.</p></div></div><div id=\"admzone480457\"><div id=\"zone-480457\"><div id=\"share-jny27esn\"><div id=\"placement-khfx0ec7\"><div id=\"banner-480457-khfx0ecl\" style=\"min-height: 0px; min-width: 0px;\"><div id=\"slot-1-480457-khfx0ecl\">\r\n</div></div></div></div> </div></div><p>Richard Kaye, chuyên gia cố vấn \r\ndanh mục đầu tư tại Nhật Bản của Comgest Global Investors, quỹ đầu tư \r\nđang nắm 165 triệu USD cổ phiếu SoftBank, nhận định: “Tôi nghĩ các bạn \r\ncần biết rằng nhân vật đang chiếm ưu thế ở Ả rập Xê út hiện nay là bạn \r\ncủa ông Son, người rất mong muốn quỹ tầm nhìn giúp đa dạng hóa tương lai\r\n kinh tế của Ả rập Xê út”.</p><p>Tháng 10/2016, Thái tử Salman nhấn mạnh\r\n vào “lịch sử lâu dài, các mối quan hệ lớn mạnh trong các ngành công \r\nnghiệp cũng như hiệu quả đầu tư cao” của SoftBank và nhà sáng lập. Tuy \r\nnhiên, Mitsuhiro Kurano, người phát ngôn của SoftBank, từ chối bình luận\r\n về các sự kiện chính trị ở Ả rập Xê út và tiềm năng ảnh hưởng với các \r\nkhoản đầu tư của công ty.</p><p>Tuy nhiên, một số nguồn thạo tin cho \r\nbiết, SoftBank dự kiến sẽ chi 25 tỷ USD vào dự án siêu đô thị mới của \r\nThái tử Salman bên bờ biển Đỏ cũng như công ty điện lực quốc doanh của Ả\r\n rập Xê út.</p><p>Tỷ phú SolfBank không phải người duy nhất muốn cái bắt\r\n tay với Ả rập Xê út. Thủ tướng Nhật Bản Shinzo Abe và Vua Salman đang \r\nnỗ lực thúc đẩy hợp tác song phương thông qua hàng loạt sáng kiến được \r\nđưa ra hồi tháng 3. Theo đó, Nhật Bản muốn xuất khẩu nhiều hơn sang Ả \r\nrập Xê út đồng thời mua dầu của quốc gia này. Trong khi đó, Trung Đông \r\nmuốn các công nghệ tiên tiến của Nhật Bản để giảm bớt phụ thuộc vào dầu \r\nmỏ.</p><p>Theo Bộ trưởng Kinh tế và Công nghiệp Nhật Bản, các công ty \r\nnhư Toyota Motor, nhà sản xuất sợi tổng hợp Toyobo hay nhà cung cấp dịch\r\n vụ kỹ thuật JFE Engineering đã trao đổi các biên bản ghi nhớ hợp tác \r\nvới đối tác Ả rập Xê út.</p></div>', 'SoftBank, công ty công nghệ', NULL, 1, 'mohamd-bin-salam.jpg', NULL, '2021-01-14 08:41:35', '2021-01-14 08:51:51', 1, 1),
(27, 5, 2, 'Cha đẻ Linux xỉ vả Intel, vì một linh kiện máy tính quan trọng gần như \"tuyệt chủng\"', 'cha-de-linux-xi-va-intel-vi-mot-linh-kien-may-tinh-quan-trong-gan-nhu-tuyet-chung', 'Theo ông Linus Torvalds, vì chính sách của Intel, loại RAM ECC đã gần như tuyệt chủng trên thị trường máy tính dành cho người dùng thông thường, dù nó cũng rất quan trọng.', '<p>Dù vài năm trước, Linus Torvalds, người sáng tạo nên nhân Linux phổ \r\nbiến hiện nay, từng tuyên bố rằng, mình sẽ cố gắng kiềm chế tính cách \r\ncộc cằn của bản thân để trở thành một người hành xử chuyên nghiệp khi \r\nlàm việc với người khác, nhưng dường như Intel đã làm ông phải phá bỏ \r\ncam kết của mình.</p><p>Vào đầu tháng Một này, trong một bài đăng trên \r\ntrang realworldtech, ông Linus đã không ngớt lời chỉ trích thẳng mặt \r\nIntel khi xem họ là nguyên nhân chính dẫn đến sự thiếu hụt của một linh \r\nkiện quan trọng trong máy tính, RAM ECC (Error Correcting Checksum) – \r\nhay RAM tự sửa lỗi. Quan trọng hơn cả, vì Intel, người dùng thông thường\r\n còn không biết đến sự tồn tại của linh kiện này.</p><p>Nếu bạn là người\r\n hay phải lên thông số cho phần cứng máy chủ, ví dụ như các CPU, các bản\r\n mạch chủ dành riêng cho máy chủ, bạn sẽ biết đến loại RAM ECC này. Về \r\nbản chất, RAM ECC sẽ chứa một mẩu bộ nhớ vô cùng nhỏ dùng để phát hiện \r\nvà chỉnh sửa các lỗi trong bộ nhớ.</p><div class=\"VCSortableInPreviewMode active\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/gmpmcrnfi24smit9wcr7yd-1200-80-16105297080651907551951.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Hiện các RAM ECC thường thấy trong những hệ thống máy chủ hơn là máy tính cho người dùng thông thường\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/gmpmcrnfi24smit9wcr7yd-1200-80-16105297080651907551951.jpg\" id=\"img_273744217911832576\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 1.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 1.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/gmpmcrnfi24smit9wcr7yd-1200-80-16105297080651907551951.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Hiện các RAM ECC thường thấy trong những hệ thống máy chủ hơn là máy tính cho người dùng thông thường</p></div></div><p><b>Tại sao tính năng ECC lại cần thiết? </b></p><p>Trong\r\n hầu hết các bộ nhớ hiện tại, cứ mỗi một từ 64-bit được lưu vào trong \r\nRAM, sẽ có 8 bit kiểm tra. Nếu một bit bị lỗi - ví dụ số 0 bị nhảy thành\r\n 1 hoặc số 1 đổi thành 0 – sẽ bị phát hiện và tự động sửa lại. Còn nếu \r\ncó 2 bit bị nhảy trong cùng một từ, chúng có thể bị phát hiện ra nhưng \r\nkhông được sửa. Còn nếu có 3 bit hoặc nhiều hơn nữa bị nhảy trong cùng \r\nmột từ, chúng vẫn có thể bị phát hiện, nhưng không hoàn toàn đảm bảo.</p><p>Có\r\n rất nhiều lý do cho lỗi nhảy bit này, có thể là vì tia vũ trụ hoặc có \r\nthể vì lỗi ngẫu nhiên của phần cứng. Một nghiên cứu về máy chủ của \r\nGoogle cho biết, khoảng 32% máy chủ (và 8% trong các bộ nhớ DIMM) của \r\nGoogle gặp phải ít nhất 1 lỗi bộ nhớ mỗi năm. Phần lớn trong số đó là \r\nlỗi một bit – và do Google sử dụng các CPU dành cho máy chủ và RAM ECC, \r\ncác cỗ máy của họ có thể tự sửa lỗi và tiếp tục hoạt động như bình \r\nthường.</p><p>Trong khi đó, đối với các máy tính của người dùng, dữ liệu\r\n của Google cho thấy, các lỗi nhảy một bit này có khả năng xảy ra cao \r\ngấp 40 lần nhảy nhiều bit. Mặc dù vậy, vì không dùng đến các RAM ECC như\r\n Google, các lỗi này không được phát hiện ra và có thể làm hệ thống \r\nthiếu ổn định cũng như hỏng dữ liệu.</p><div class=\"VCSortableInPreviewMode noCaption\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/2013transcendts512mlk72v6n-straightened-16105296865631900936762.jpg\" data-fancybox-group=\"img-lightbox\" title=\"\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/2013transcendts512mlk72v6n-straightened-16105296865631900936762.jpg\" id=\"img_273744129807777792\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 2.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 2.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/2013transcendts512mlk72v6n-straightened-16105296865631900936762.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div></div><p><b>Việc nhảy bit không phải lúc nào cũng ngẫu nhiên </b></p><p>Không\r\n phải mọi lỗi trong RAM đều ngẫu nhiên do lỗi phần cứng hay các sóng \r\nđiện từ EMF. Trong những năm gần đây, các nhà nghiên cứu phát hiện ra \r\nngày càng nhiều các cuộc tấn công kênh phụ (side channel attack) thông \r\nqua việc tiếp cận vật lý tới hệ thống.</p><p>Từ việc sử dụng lỗi nhảy \r\nbit một cách có điều khiển trong những khu vực RAM có thể tiếp cận tới \r\nmột ứng dụng nào đó, kẻ tấn công có thể suy luận ra hoặc chỉnh sửa các \r\ngiá trị dữ liệu trong các vùng RAM đáng nhẽ họ không thể tiếp cận.</p><p>Cho\r\n dù RAM ECC không thể giảm nhẹ cuộc tấn công theo dạng RAMBleed này, \r\nnhằm suy luận giá trị dữ liệu trong các khu vực lân cận bộ nhớ, nói \r\nchung nó có thể ngăn cuộc tấn công kiểu Rowhammer (kiểu tấn công bằng \r\ncách truy cập liên tục vào một vị trí trên DRAM để gây lỗi nhảy bit, có \r\nthể thực hiện từ xa) khi làm hệ thống bị tắt mà không ảnh hưởng gì đến \r\ndữ liệu. (Phần lớn các hệ thống dùng RAM ECC được cấu hình để dừng hoạt \r\nđộng hoàn toàn nếu phát hiện ra một lỗi không thể sửa được).</p><div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/new-ffs-rowhammer-attack-targets-linux-vm-setups-507290-2-16105302518191270890428.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Cuộc tấn công kiểu Rowhammer có thể ngăn chặn được nếu dùng RAM ECC\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/new-ffs-rowhammer-attack-targets-linux-vm-setups-507290-2-16105302518191270890428.jpg\" id=\"img_273746498300846080\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 3.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 3.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/new-ffs-rowhammer-attack-targets-linux-vm-setups-507290-2-16105302518191270890428.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Cuộc tấn công kiểu Rowhammer có thể ngăn chặn được nếu dùng RAM ECC</p></div></div><div id=\"admzone480457\"><div id=\"zone-480457\"><div id=\"share-jny27esn\"><div id=\"placement-khg2nebj\"><div id=\"banner-480457-khg2nec0\" style=\"min-height: 0px; min-width: 0px;\"><div id=\"slot-1-480457-khg2nec0\">\r\n</div></div></div></div> </div></div><p><b>Tại sao lại là Intel? </b></p><p>Thế nhưng rất ít người dùng thông thường biết đến sự tồn tại của RAM ECC và theo Torvalds, đó là lỗi của Intel.</p><p>Đã\r\n từng có thời bạn mua một CPU thông thường, nhưng vẫn được hỗ trợ RAM \r\nECC, nhưng đó là câu chuyện của 15 năm trước với các chipset 975X. Sau \r\nđó, tính năng này chỉ được Intel trang bị cho các dòng CPU máy chủ như \r\nXeon. Lập luận của Intel chỉ đơn giản là \"người tiêu dùng không cần đến \r\nECC\".</p><p>Nhưng như các lý do kể trên, những cuộc tấn công kiểu \r\nRowhammer và các lỗi nhảy bit vẫn tiếp tục diễn ra – điều đó chứng tỏ \r\nngười dùng thông thường cũng cần đến nó – không như tuyên bố của Intel. \r\nKhông có sự hỗ trợ từ CPU Intel – vốn là hãng có vị thế gần như độc \r\nquyền trong nhiều năm nay – các RAM ECC dành cho người dùng thông thường\r\n cũng vì thế dần biến mất.</p><div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/linus-torvalds-eec-ram-16105296867411833716582.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Intel đã làm ông Linus Torvalds phá vỡ cam kết giữ bình tình của mình.\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/linus-torvalds-eec-ram-16105296867411833716582.jpg\" id=\"img_273744129311809536\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 4.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 4.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/linus-torvalds-eec-ram-16105296867411833716582.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Intel đã làm ông Linus Torvalds phá vỡ cam kết giữ bình tình của mình.</p></div></div><p>\"<i>Và\r\n các nhà sản xuất bộ nhớ sẽ nói rằng nó là vì tính kinh tế và hiệu năng \r\nthấp. Và họ là những thằng khốn dối trá – hãy nhìn vào cuộc tấn công \r\nkiểu Row-hammer để thấy vấn đề này đã tồn tại từ nhiều thế hệ nay, nhưng\r\n những kẻ khốn này vẫn vui vẻ bán phần cứng hỏng cho người dùng và nói \r\nrằng đó là một cuộc \"tấn công\", khi nó vẫn luôn hiện diện ở đó</i>.\"</p><p>\"<i>Đã\r\n bao nhiêu lần các lỗi nhảy bit tương tự như cuộc tấn công Rowhammer xảy\r\n ra chỉ vì vận đen rơi đúng vào tải công việc chứ không phải bị tấn \r\ncông? Chúng ta sẽ không bao giờ biết được. Bởi vì Intel đã đẩy phần \r\nthiệt đó về người dùng</i>.\"</p><p>Nhưng tại sao Intel lại làm vậy? Theo\r\n ông Torvalds, đó là cách Intel phân khúc thị trường của mình. Các CPU \r\ndành cho người dùng thông thường với giá rẻ hơn và lợi nhuận thấp hơn, \r\nnhưng lại thiếu các tính năng bảo vệ cần thiết như ECC, sẽ không giẫm \r\nchân lên các CPU máy chủ - vốn đắt đỏ hơn và nhiều lợi nhuận hơn – khi \r\nhướng tới các doanh nghiệp lớn.</p><p>Thông thường, người ta cho rằng \r\nchi phí là nguyên nhân các phần cứng hỗ trợ ECC hiếm khi dành cho người \r\ndùng thông thường. Tuy nhiên, hãy nhìn vào các RAM ECC. Ngay cả khi \r\nchúng rất khó tìm mua được, giá bán lẻ của chúng cũng chỉ cao hơn khoảng\r\n 20% so với giá RAM thường. Tuy nhiên vấn đề lại là, nếu các bản mạch \r\nchủ và CPU không hỗ trợ nó, lắp ráp RAM ECC cũng không mang lại lợi ích \r\ngì.</p><p>Về lý thuyết, dòng CPU Ryzen của AMD cũng hỗ trợ ECC, dù không\r\n chính thức. Nhưng chính vì vậy, điều này cũng không có gì đảm bảo các \r\nnhà sản xuất các linh kiện khác, như bo mạch chủ, hoặc các nhà OEM sản \r\nxuất máy tính, hỗ trợ tính năng này – ngay cả khi họ đã tuyên bố như \r\nvậy. Cách duy nhất chắc chắn một bo mạch chủ Ryzen nào đó tương thích \r\nvới ECC là chạy một ứng dụng nào đó gây ra lỗi nhảy bit để kích hoạt \r\ntính năng đó.</p><p style=\"text-align: left;\">Một hy vọng khác với người\r\n dùng là RAM DDR5 đang bắt đầu ra mắt trong năm 2020. Bên cạnh các cải \r\ntiến về dung lượng, băng thông và sức mạnh, điều đáng chú ý là các mã tự\r\n sửa lỗi ECC sẽ được nhúng ngay trong chip nhớ. Khi đó, sự phổ biến của \r\nthế hệ RAM mới này có thể sẽ kéo theo sự hỗ trợ rộng rãi hơn từ các linh\r\n kiện khác như bo mạch chủ.</p><p style=\"text-align: right;\"><i>Tham khảo ArsTechnica</i></p>', 'Cha đẻ Linux, Intel, linh kiện máy tính, ram ecc', NULL, 1, 'Linus-Torvalds.jpg', NULL, '2021-01-14 09:06:56', '2021-01-13 09:29:25', 1, 1),
(25, 5, 2, 'Jack Ma thu về số tiền gấp 8 lần Amazon, Walmart, eBay cộng lại chỉ trong 1 ngày', 'jack-ma-thu-ve-so-tien-gap-8-lan-amazon-walmart-ebay-cong-lai-chi-trong-1-ngay', 'Lễ Độc Thân năm nay, Alibaba - thương hiệu mua sắm trực tuyến lớn nhất Trung Quốc đã phá kỉ lục của chính họ khi thu về tới 17,7 tỉ USD chỉ trong 1 ngày giảm giá - gấp gần 8 lần ngày Black Friday 2016 tại Mỹ.', '<h1 class=\"kbwc-title clearfix\">Nhờ bỏ ra 1 tỷ USD đầu tư công nghệ này,\r\n Jack Ma thu về số tiền gấp 8 lần Amazon, Walmart, Target hay eBay cộng \r\nlại chỉ trong 1 ngày</h1><div><p>Ngày hôm đó, toàn bộ nhân viên nhân viên kĩ thuật được điều động tập \r\ntrung ở một phòng để kiểm soát hàng triệu người dùng liên tục truy cập \r\nvào hệ thống mua sắm.</p>\r\n\r\n<p><i>\"Đó giống như 1 buổi diễu hành hay tập trận vậy\"</i>, Yunfei - Giám đốc sản phẩm của Alibaba Cloud miêu tả trụ sở làm việc ngày 11/11.</p>\r\n\r\n<p>Ban đầu, ngày 11/11 ở Trung Quốc cũng chỉ là một ngày tượng trưng cho\r\n những người độc thân, nhưng sau này đã trở thành ngày hội mua sắm của \r\ntoàn dân nước này.</p>\r\n\r\n<p>Tương tự như Black Friday và Cyber Monday, ngày này được coi như 1 lễ\r\n lớn trong năm. Với những mặt hàng giảm giá, người tiêu dùng Trung Quốc \r\ncó thể lựa chọn và sắm sửa những vật dụng cần thiết, chuẩn bị cho ngày \r\nTết truyền thống.</p>\r\n\r\n<p>Ông Yunfei chia sẻ:</p>\r\n\r\n<p><i>\"Quang cảnh năm nay khác hẳn mọi năm, đặc biệt là với chúng tôi, \r\nnhững người chỉ quan sát từ camera. Mặc dù là nửa đêm, nhưng ngay khi mở\r\n cửa vào đón khách, hàng nghìn lượt khách đã đua nhau chen chúc.</i></p>\r\n\r\n<p><i>Chúng tôi chẳng biết làm gì ngoài ăn mừng và vỗ tay. Chưa kịp ăn \r\nmừng xong thì doanh số bán hàng đã đạt 1 tỷ nhân dân tệ (tương đương 145\r\n nghìn USD). Chúng tôi còn không thể tin nổi kết quả đó!\".</i></p>\r\n\r\n<p>Yunfei cho biết, vào thời gian cao điểm của ngày Lễ độc thân năm nay,\r\n cơ sở dữ liệu ghi nhận có tới 175.000 giao dịch và 120.000 thanh toán \r\ncùng lúc chỉ trong 1 giây.</p>\r\n\r\n<p><i>\"Nhờ những ngày này mà chúng tôi có cơ hội nghiêm túc huấn luyện \r\ncho các kĩ sư ở đây. Qua đó, ngày càng nâng cao khả năng của họ, hướng \r\ntới phục vụ những thị trường lớn hơn ngoài Trung Quốc\".</i></p>\r\n\r\n<div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\">\r\n<div style=\"position: relative; display: inline-block;\"><a href=\"https://genk.mediacdn.vn/2016/photo-0-1480911684824.jpg\" data-fancybox-group=\"img-lightbox\" title=\"\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img alt=\"\" id=\"img_4df85f10-baa2-11e6-bee9-8ba0eb6afe81\" src=\"https://genk.mediacdn.vn/thumb_w/640/2016/photo-0-1480911684824.jpg\" rel=\"https://genk.mediacdn.vn/2016/photo-0-1480911684824.jpg\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/2016/photo-0-1480911684824.jpg\" class=\"lightbox-content\" style=\"margin-top: 137px; padding-top: unset;\"></a></div>\r\n\r\n\r\n</div>\r\n\r\n<p><span class=\"IMSNoChangeStyle\" style=\"font-size:20px;\"><strong style=\"font-size: 12.8pt;\">Khả năng tự cung tự cấp</strong></span></p>\r\n\r\n<p>Không ít người đặt ra câu hỏi: tại sao Alibaba Cloud - công nghệ được\r\n đầu tư 1 tỷ USD, có thể kết thúc ngày Lễ độc thân với chiến thắng vang \r\ndội như thế?</p>\r\n\r\n<p>Yunfei giải thích về hệ thống trơn tru của Alibaba Cloud: <i>\"Trên \r\ncác đám mây dự trữ nói chung, có rất nhiều công cụ cần phải xử lí. Điều \r\nkhác biệt lớn nhất chúng tôi có thể mang đến đó là chúng tôi tự tạo nên \r\ncác công cụ hỗ trợ cho hệ thống, vì vậy chúng tôi kiểm soát chúng vô \r\ncùng dễ dàng\".</i></p>\r\n\r\n<div id=\"admzone480457\"><div id=\"zone-480457\"><div id=\"share-jny27esn\"><div id=\"placement-khfyn14b\"><div id=\"banner-480457-khfyn14l\" style=\"min-height: 0px; min-width: 0px;\"><div id=\"slot-1-480457-khfyn14l\">\r\n</div></div></div></div> </div></div><p>Bằng cách chia nhỏ và lọc người \r\ndùng theo những thông tin định vị, mỗi khách hàng truy cập vào Alibaba \r\nđều sẽ nhận được luồng thông tin nhanh nhất từ cơ sở dữ liệu gần nhất. \r\nDo đó, hệ thống Alibaba không bị nghẽn mạng hay treo do có quá nhiều \r\ntruy cập cùng lúc.</p>\r\n\r\n<p>Được biết, có tới 10.000 máy chủ chạy cùng lúc ở hệ thống này, với lưu lượng thông tin 1 tỷ Gb.</p>\r\n\r\n<p>Không riêng gì phần mềm, Alibaba còn tự thiết kế phần cứng với những \r\nđối tác nổi tiếng như AMD với các sản phẩm chip đồ họa, và mới đây là \r\nhợp đồng với NVIDA chế tác AliCloud HPC, một công cụ tăng tốc GPU.</p>\r\n\r\n<p>MaxCompute, công ty xử lý dữ liệu cho Alibaba cũng xác nhận đã hoàn \r\nthành 1,98 triệu tác vụ chỉ trong ngày 11/11. 180 petabytes dữ liệu được\r\n chuyển đi từ 54.000 máy tính tại 7 trung tâm dữ liệu.</p>\r\n\r\n<p><i>\"Nếu chúng tôi không thể tự xây dựng hệ thống, những điều đó khó có thể xảy ra\"</i>, Yunfei cũng đưa ra nhận xét về những con số.</p>\r\n\r\n<div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\">\r\n<div><a href=\"https://genk.mediacdn.vn/2016/photo-1-1480911684826.jpg\" data-fancybox-group=\"img-lightbox\" title=\"\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img alt=\"\" id=\"img_4dda9de0-baa2-11e6-bee9-8ba0eb6afe81\" src=\"https://genk.mediacdn.vn/thumb_w/640/2016/photo-1-1480911684826.jpg\" rel=\"https://genk.mediacdn.vn/2016/photo-1-1480911684826.jpg\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/2016/photo-1-1480911684826.jpg\" class=\"lightbox-content\"></a></div>\r\n\r\n\r\n</div>\r\n\r\n<p><span class=\"IMSNoChangeStyle\" style=\"font-size:20px;\"><strong>Tầm nhìn</strong></span></p>\r\n\r\n<p>Yunfei và nhóm của ông đã chuẩn bị cho ngày Lễ Độc Thân từ hơn 6 \r\ntháng trước. Họ lên kế hoạch, xây dựng công nghệ dựa vào những dự đoán \r\nsự phát triển thị trường và đặt ra dự tính về những con số.</p>\r\n\r\n<p><i>\"Tới khi chúng tôi hoàn thiện hệ thống, chúng tôi sẽ sử dụng những con số dự tính làm mục tiêu ban đầu\"</i>, Yunfei chia sẻ.</p>\r\n\r\n<p>Nhưng những ước tính thì không thể chính xác hoàn toàn. Do đó, họ \r\ncùng nhau đưa ra các phương án để giải quyết tình huống, cũng như tự tạo\r\n tình huống để thử giải quyết.</p>\r\n\r\n<p><i>\"Các đồng nghiệp của tôi đã rất vất vả, mỗi ngày họ đều làm việc \r\ndưới áp lực rất lớn để mô phỏng ngày Lễ Độc Thân. Nhờ vậy mà chúng tôi \r\nmới tìm ra được các phương án giải quyết tốt hơn\",</i> Yunfei đầy tự hào khi nói về các đồng nghiệp.</p>\r\n\r\n<p><i>\"Chúng tôi thường có câu nói đùa rằng, nếu chưa trải nghiệm ngày \r\nLễ Độc Thân bao giờ, các bạn chưa phải là một thành viên của Alibaba \r\nchính hiệu\".</i></p>\r\n\r\n<p style=\"text-align: right;\"><i>Theo Trí Thức Trẻ</i></p></div><div><br></div>', 'Jack Ma, alibaba đầu tư công nghệ', NULL, 1, 'alibaba-lai-to.webp', NULL, '2021-01-14 08:35:20', '2021-01-14 08:38:21', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` tinyint(4) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyword` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `saleoff` int(11) DEFAULT 0,
  `hot` int(11) DEFAULT NULL,
  `view` int(11) DEFAULT NULL,
  `notestatus` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `title`, `slug`, `description`, `content`, `keyword`, `price`, `created`, `status`, `photo`, `del`, `created_at`, `updated_at`, `saleoff`, `hot`, `view`, `notestatus`, `shipping`, `weight`, `user_id`, `currency`) VALUES
(1, 2, 'sản phẩm số 1', 'san-pham-so-1-1', 'thanh cong', '<div><img src=\"http://hkfashion.vn/upload/Images/home1.jpg\" /></div>\r\n\r\n<div>&nbsp;</div>', 'tu khoa', 3, NULL, 1, 'ao-bao-ho-lao-dong-xanh.png', NULL, '2020-08-11 20:11:07', '2021-01-04 08:41:51', 20, 0, NULL, NULL, NULL, NULL, 12, 'USD'),
(2, 2, 'sản phẩm số 2', 'san-pham-so-2', 'thông tin dien giai ngan', 'chung toi thanh cong roi ban', 'tu khoa tim kiem', 4, NULL, 1, 'ao-bao-ho-lao-dong.png', NULL, '2020-08-26 06:57:54', '2021-01-04 08:42:14', NULL, 1, NULL, NULL, NULL, NULL, 12, 'USD'),
(5, 2, 'SAN PHAM SO 1', 'san-pham-so-1-2', 'THÔNG TIN NGAN GON', 'SDFSDFS', 'SAN PHAM SO 1', 200, NULL, 1, 'non-bao-ho-lao-dong.png', NULL, '2020-09-22 01:35:20', '2021-01-04 08:42:45', NULL, 1, NULL, NULL, NULL, NULL, 12, 'USD');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tag` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `seo` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

CREATE TABLE `template` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` tinyint(4) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyword` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `view` int(11) DEFAULT 1,
  `hot` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`id`, `category_id`, `title`, `slug`, `description`, `content`, `keyword`, `created`, `status`, `photo`, `created_at`, `updated_at`, `view`, `hot`) VALUES
(26, 5, 'SoftBank được bơm 45 tỷ USD trong 45 phút,  giấc mơ của Masayoshi Son thành hiện thực', 'softbank-duoc-bom-45-ty-usd-trong-45-phut-giac-mo-cua-masayoshi-son-thanh-hien-thuc', 'Không chỉ đồng ý bơm 45 tỷ USD trong 45 phút, Thái tử Ả rập sẽ biến giấc mơ của Masayoshi Son thành hiện thực', '<h2 class=\"knc-sapo\">Tỷ phú Masayoshi Son của SoftBank đang tiến gần hơn\r\n tới giấc mơ trở thành quỹ đầu tư lớn nhất trong lĩnh vực công nghệ khi \r\nThái tử Ả rập Xê út Mohammed bin Salman đang có kế hoạch chi tới 100 tỷ \r\nUSD cho công ty.</h2><div><p>Ở thời điểm hiện tại, Thái tử Salman đã là nhà đầu tư lớn nhất, đóng \r\ngóp một nửa số tiền mà Masayoshi Son quyên góp nhằm đưa tên tuổi Quỹ tầm\r\n nhìn SoftBank trở thành số một thế giới trong lĩnh vực đầu tư công \r\nnghệ. Tuy nhiên, số tiền có thể chưa dừng lại ở đó khi Thái tử Salman \r\nđang tiến hành cuộc truy quét tham nhũng ở Ả rập Xê út, động thái được \r\nmô tả là củng cố quyền lực của người sẽ trở thành Quốc vương của Vương \r\nquốc giàu dầu mỏ.</p><p>Khi quyền lực của Thái tử Salman lớn hơn, số \r\ntiền nhân vật này đổ cho Quỹ tầm nhìn SoftBank có thể tăng theo tỷ lệ \r\nthuận. Việc có nhiều tiền cũng khiến Softbank đầu tư mạnh dạn hơn mà \r\nkhông quá nặng nề với bài toán tìm doanh thu nhằm giảm gánh nặng. Cùng \r\nvới đó, người ta cũng chẳng còn nghi ngờ về sự bền vững trong các khoản \r\nđầu tư của Thái tử Salman.</p><p>Ông Mana Nakazora, trưởng phòng phân \r\ntích tín dụng của BNP Paribas SA, nhận định: “Ả rập Xê út có tiền để đầu\r\n tư, điều đó có nghĩa là khả năng tài trợ cho một quỹ tầm nhìn thứ 2, \r\nhoặc thứ ba. Sức ảnh hưởng lớn từ Thái tử Salman càng làm cho khả năng \r\nđó có thể trở thành hiện thực. Hiện tại, Ả rập Xê út đã chi 45 tỷ USD \r\ncho quỹ này, biến họ trở thành nhà đầu tư lớn nhất. Thỏa thuận khổng lồ \r\nđạt được trong cuộc họp kéo dài 45 phút giữa Masayoshi Son và Thái tử \r\nSalman.</p><p>Với Quỹ tầm nhìn, nhà sáng lập SoftBank đang tìm kiếm sự \r\ngia tăng ảnh hưởng trong vai trò một nhà đầu tư công nghệ, đánh cược \r\ntương lai vào trí tuệ nhân tạo, thiết bị kết nối hay xa hơn là sự kết \r\nhợp giữa máy tính với con người. Quỹ này đã huy động được 93 tỷ USD ở \r\nthời điểm hiện tại. Ngoài tiền từ Ả rập Xê út, quỹ còn có 28 tỷ USD từ \r\nSoftBank và 20 tỷ USD từ các nhà đầu tư khác.</p><div class=\"VCSortableInPreviewMode active\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/2017/photo-1-1513042496220.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Thái tử Salman và nhà sáng lập SoftBank Masayoshi Son.\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/2017/photo-1-1513042496220.jpg\" id=\"img_a940d820-dedc-11e7-aad6-b357a4250db9\" alt=\"Không chỉ đồng ý bơm 45 tỷ USD trong 45 phút, Thái tử Ả rập sẽ biến giấc mơ của Masayoshi Son thành hiện thực? - Ảnh 1.\" title=\"Không chỉ đồng ý bơm 45 tỷ USD trong 45 phút, Thái tử Ả rập sẽ biến giấc mơ của Masayoshi Son thành hiện thực? - Ảnh 1.\" rel=\"lightbox\" type=\"photo\" style=\"max-width:100%;\" data-original=\"https://genk.mediacdn.vn/2017/photo-1-1513042496220.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Thái tử Salman và nhà sáng lập SoftBank Masayoshi Son.</p></div></div><div id=\"admzone480457\"><div id=\"zone-480457\"><div id=\"share-jny27esn\"><div id=\"placement-khfx0ec7\"><div id=\"banner-480457-khfx0ecl\" style=\"min-height: 0px; min-width: 0px;\"><div id=\"slot-1-480457-khfx0ecl\">\r\n</div></div></div></div> </div></div><p>Richard Kaye, chuyên gia cố vấn \r\ndanh mục đầu tư tại Nhật Bản của Comgest Global Investors, quỹ đầu tư \r\nđang nắm 165 triệu USD cổ phiếu SoftBank, nhận định: “Tôi nghĩ các bạn \r\ncần biết rằng nhân vật đang chiếm ưu thế ở Ả rập Xê út hiện nay là bạn \r\ncủa ông Son, người rất mong muốn quỹ tầm nhìn giúp đa dạng hóa tương lai\r\n kinh tế của Ả rập Xê út”.</p><p>Tháng 10/2016, Thái tử Salman nhấn mạnh\r\n vào “lịch sử lâu dài, các mối quan hệ lớn mạnh trong các ngành công \r\nnghiệp cũng như hiệu quả đầu tư cao” của SoftBank và nhà sáng lập. Tuy \r\nnhiên, Mitsuhiro Kurano, người phát ngôn của SoftBank, từ chối bình luận\r\n về các sự kiện chính trị ở Ả rập Xê út và tiềm năng ảnh hưởng với các \r\nkhoản đầu tư của công ty.</p><p>Tuy nhiên, một số nguồn thạo tin cho \r\nbiết, SoftBank dự kiến sẽ chi 25 tỷ USD vào dự án siêu đô thị mới của \r\nThái tử Salman bên bờ biển Đỏ cũng như công ty điện lực quốc doanh của Ả\r\n rập Xê út.</p><p>Tỷ phú SolfBank không phải người duy nhất muốn cái bắt\r\n tay với Ả rập Xê út. Thủ tướng Nhật Bản Shinzo Abe và Vua Salman đang \r\nnỗ lực thúc đẩy hợp tác song phương thông qua hàng loạt sáng kiến được \r\nđưa ra hồi tháng 3. Theo đó, Nhật Bản muốn xuất khẩu nhiều hơn sang Ả \r\nrập Xê út đồng thời mua dầu của quốc gia này. Trong khi đó, Trung Đông \r\nmuốn các công nghệ tiên tiến của Nhật Bản để giảm bớt phụ thuộc vào dầu \r\nmỏ.</p><p>Theo Bộ trưởng Kinh tế và Công nghiệp Nhật Bản, các công ty \r\nnhư Toyota Motor, nhà sản xuất sợi tổng hợp Toyobo hay nhà cung cấp dịch\r\n vụ kỹ thuật JFE Engineering đã trao đổi các biên bản ghi nhớ hợp tác \r\nvới đối tác Ả rập Xê út.</p></div>', 'SoftBank, công ty công nghệ', NULL, 1, 'mohamd-bin-salam.jpg', '2021-01-14 08:41:35', '2021-01-14 08:51:51', 1, 1),
(27, 5, 'Cha đẻ Linux xỉ vả Intel, vì một linh kiện máy tính quan trọng gần như \"tuyệt chủng\"', 'cha-de-linux-xi-va-intel-vi-mot-linh-kien-may-tinh-quan-trong-gan-nhu-tuyet-chung', 'Theo ông Linus Torvalds, vì chính sách của Intel, loại RAM ECC đã gần như tuyệt chủng trên thị trường máy tính dành cho người dùng thông thường, dù nó cũng rất quan trọng.', '<p>Dù vài năm trước, Linus Torvalds, người sáng tạo nên nhân Linux phổ \r\nbiến hiện nay, từng tuyên bố rằng, mình sẽ cố gắng kiềm chế tính cách \r\ncộc cằn của bản thân để trở thành một người hành xử chuyên nghiệp khi \r\nlàm việc với người khác, nhưng dường như Intel đã làm ông phải phá bỏ \r\ncam kết của mình.</p><p>Vào đầu tháng Một này, trong một bài đăng trên \r\ntrang realworldtech, ông Linus đã không ngớt lời chỉ trích thẳng mặt \r\nIntel khi xem họ là nguyên nhân chính dẫn đến sự thiếu hụt của một linh \r\nkiện quan trọng trong máy tính, RAM ECC (Error Correcting Checksum) – \r\nhay RAM tự sửa lỗi. Quan trọng hơn cả, vì Intel, người dùng thông thường\r\n còn không biết đến sự tồn tại của linh kiện này.</p><p>Nếu bạn là người\r\n hay phải lên thông số cho phần cứng máy chủ, ví dụ như các CPU, các bản\r\n mạch chủ dành riêng cho máy chủ, bạn sẽ biết đến loại RAM ECC này. Về \r\nbản chất, RAM ECC sẽ chứa một mẩu bộ nhớ vô cùng nhỏ dùng để phát hiện \r\nvà chỉnh sửa các lỗi trong bộ nhớ.</p><div class=\"VCSortableInPreviewMode active\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/gmpmcrnfi24smit9wcr7yd-1200-80-16105297080651907551951.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Hiện các RAM ECC thường thấy trong những hệ thống máy chủ hơn là máy tính cho người dùng thông thường\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/gmpmcrnfi24smit9wcr7yd-1200-80-16105297080651907551951.jpg\" id=\"img_273744217911832576\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 1.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 1.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/gmpmcrnfi24smit9wcr7yd-1200-80-16105297080651907551951.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Hiện các RAM ECC thường thấy trong những hệ thống máy chủ hơn là máy tính cho người dùng thông thường</p></div></div><p><b>Tại sao tính năng ECC lại cần thiết? </b></p><p>Trong\r\n hầu hết các bộ nhớ hiện tại, cứ mỗi một từ 64-bit được lưu vào trong \r\nRAM, sẽ có 8 bit kiểm tra. Nếu một bit bị lỗi - ví dụ số 0 bị nhảy thành\r\n 1 hoặc số 1 đổi thành 0 – sẽ bị phát hiện và tự động sửa lại. Còn nếu \r\ncó 2 bit bị nhảy trong cùng một từ, chúng có thể bị phát hiện ra nhưng \r\nkhông được sửa. Còn nếu có 3 bit hoặc nhiều hơn nữa bị nhảy trong cùng \r\nmột từ, chúng vẫn có thể bị phát hiện, nhưng không hoàn toàn đảm bảo.</p><p>Có\r\n rất nhiều lý do cho lỗi nhảy bit này, có thể là vì tia vũ trụ hoặc có \r\nthể vì lỗi ngẫu nhiên của phần cứng. Một nghiên cứu về máy chủ của \r\nGoogle cho biết, khoảng 32% máy chủ (và 8% trong các bộ nhớ DIMM) của \r\nGoogle gặp phải ít nhất 1 lỗi bộ nhớ mỗi năm. Phần lớn trong số đó là \r\nlỗi một bit – và do Google sử dụng các CPU dành cho máy chủ và RAM ECC, \r\ncác cỗ máy của họ có thể tự sửa lỗi và tiếp tục hoạt động như bình \r\nthường.</p><p>Trong khi đó, đối với các máy tính của người dùng, dữ liệu\r\n của Google cho thấy, các lỗi nhảy một bit này có khả năng xảy ra cao \r\ngấp 40 lần nhảy nhiều bit. Mặc dù vậy, vì không dùng đến các RAM ECC như\r\n Google, các lỗi này không được phát hiện ra và có thể làm hệ thống \r\nthiếu ổn định cũng như hỏng dữ liệu.</p><div class=\"VCSortableInPreviewMode noCaption\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/2013transcendts512mlk72v6n-straightened-16105296865631900936762.jpg\" data-fancybox-group=\"img-lightbox\" title=\"\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/2013transcendts512mlk72v6n-straightened-16105296865631900936762.jpg\" id=\"img_273744129807777792\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 2.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 2.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/2013transcendts512mlk72v6n-straightened-16105296865631900936762.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div></div><p><b>Việc nhảy bit không phải lúc nào cũng ngẫu nhiên </b></p><p>Không\r\n phải mọi lỗi trong RAM đều ngẫu nhiên do lỗi phần cứng hay các sóng \r\nđiện từ EMF. Trong những năm gần đây, các nhà nghiên cứu phát hiện ra \r\nngày càng nhiều các cuộc tấn công kênh phụ (side channel attack) thông \r\nqua việc tiếp cận vật lý tới hệ thống.</p><p>Từ việc sử dụng lỗi nhảy \r\nbit một cách có điều khiển trong những khu vực RAM có thể tiếp cận tới \r\nmột ứng dụng nào đó, kẻ tấn công có thể suy luận ra hoặc chỉnh sửa các \r\ngiá trị dữ liệu trong các vùng RAM đáng nhẽ họ không thể tiếp cận.</p><p>Cho\r\n dù RAM ECC không thể giảm nhẹ cuộc tấn công theo dạng RAMBleed này, \r\nnhằm suy luận giá trị dữ liệu trong các khu vực lân cận bộ nhớ, nói \r\nchung nó có thể ngăn cuộc tấn công kiểu Rowhammer (kiểu tấn công bằng \r\ncách truy cập liên tục vào một vị trí trên DRAM để gây lỗi nhảy bit, có \r\nthể thực hiện từ xa) khi làm hệ thống bị tắt mà không ảnh hưởng gì đến \r\ndữ liệu. (Phần lớn các hệ thống dùng RAM ECC được cấu hình để dừng hoạt \r\nđộng hoàn toàn nếu phát hiện ra một lỗi không thể sửa được).</p><div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/new-ffs-rowhammer-attack-targets-linux-vm-setups-507290-2-16105302518191270890428.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Cuộc tấn công kiểu Rowhammer có thể ngăn chặn được nếu dùng RAM ECC\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/new-ffs-rowhammer-attack-targets-linux-vm-setups-507290-2-16105302518191270890428.jpg\" id=\"img_273746498300846080\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 3.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 3.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/new-ffs-rowhammer-attack-targets-linux-vm-setups-507290-2-16105302518191270890428.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Cuộc tấn công kiểu Rowhammer có thể ngăn chặn được nếu dùng RAM ECC</p></div></div><div id=\"admzone480457\"><div id=\"zone-480457\"><div id=\"share-jny27esn\"><div id=\"placement-khg2nebj\"><div id=\"banner-480457-khg2nec0\" style=\"min-height: 0px; min-width: 0px;\"><div id=\"slot-1-480457-khg2nec0\">\r\n</div></div></div></div> </div></div><p><b>Tại sao lại là Intel? </b></p><p>Thế nhưng rất ít người dùng thông thường biết đến sự tồn tại của RAM ECC và theo Torvalds, đó là lỗi của Intel.</p><p>Đã\r\n từng có thời bạn mua một CPU thông thường, nhưng vẫn được hỗ trợ RAM \r\nECC, nhưng đó là câu chuyện của 15 năm trước với các chipset 975X. Sau \r\nđó, tính năng này chỉ được Intel trang bị cho các dòng CPU máy chủ như \r\nXeon. Lập luận của Intel chỉ đơn giản là \"người tiêu dùng không cần đến \r\nECC\".</p><p>Nhưng như các lý do kể trên, những cuộc tấn công kiểu \r\nRowhammer và các lỗi nhảy bit vẫn tiếp tục diễn ra – điều đó chứng tỏ \r\nngười dùng thông thường cũng cần đến nó – không như tuyên bố của Intel. \r\nKhông có sự hỗ trợ từ CPU Intel – vốn là hãng có vị thế gần như độc \r\nquyền trong nhiều năm nay – các RAM ECC dành cho người dùng thông thường\r\n cũng vì thế dần biến mất.</p><div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\"><div><a href=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/linus-torvalds-eec-ram-16105296867411833716582.jpg\" data-fancybox-group=\"img-lightbox\" title=\"Intel đã làm ông Linus Torvalds phá vỡ cam kết giữ bình tình của mình.\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img src=\"https://genk.mediacdn.vn/thumb_w/660/139269124445442048/2021/1/13/linus-torvalds-eec-ram-16105296867411833716582.jpg\" id=\"img_273744129311809536\" alt=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 4.\" title=\"Cha đẻ Linux lại xỉ vả Intel, vì làm một linh kiện máy tính quan trọng gần như tuyệt chủng - Ảnh 4.\" rel=\"lightbox\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/139269124445442048/2021/1/13/linus-torvalds-eec-ram-16105296867411833716582.jpg\" class=\"lightbox-content\" width=\"\" height=\"\"></a></div><div class=\"PhotoCMS_Caption\"><p data-placeholder=\"[nhập chú thích]\" class=\"\">Intel đã làm ông Linus Torvalds phá vỡ cam kết giữ bình tình của mình.</p></div></div><p>\"<i>Và\r\n các nhà sản xuất bộ nhớ sẽ nói rằng nó là vì tính kinh tế và hiệu năng \r\nthấp. Và họ là những thằng khốn dối trá – hãy nhìn vào cuộc tấn công \r\nkiểu Row-hammer để thấy vấn đề này đã tồn tại từ nhiều thế hệ nay, nhưng\r\n những kẻ khốn này vẫn vui vẻ bán phần cứng hỏng cho người dùng và nói \r\nrằng đó là một cuộc \"tấn công\", khi nó vẫn luôn hiện diện ở đó</i>.\"</p><p>\"<i>Đã\r\n bao nhiêu lần các lỗi nhảy bit tương tự như cuộc tấn công Rowhammer xảy\r\n ra chỉ vì vận đen rơi đúng vào tải công việc chứ không phải bị tấn \r\ncông? Chúng ta sẽ không bao giờ biết được. Bởi vì Intel đã đẩy phần \r\nthiệt đó về người dùng</i>.\"</p><p>Nhưng tại sao Intel lại làm vậy? Theo\r\n ông Torvalds, đó là cách Intel phân khúc thị trường của mình. Các CPU \r\ndành cho người dùng thông thường với giá rẻ hơn và lợi nhuận thấp hơn, \r\nnhưng lại thiếu các tính năng bảo vệ cần thiết như ECC, sẽ không giẫm \r\nchân lên các CPU máy chủ - vốn đắt đỏ hơn và nhiều lợi nhuận hơn – khi \r\nhướng tới các doanh nghiệp lớn.</p><p>Thông thường, người ta cho rằng \r\nchi phí là nguyên nhân các phần cứng hỗ trợ ECC hiếm khi dành cho người \r\ndùng thông thường. Tuy nhiên, hãy nhìn vào các RAM ECC. Ngay cả khi \r\nchúng rất khó tìm mua được, giá bán lẻ của chúng cũng chỉ cao hơn khoảng\r\n 20% so với giá RAM thường. Tuy nhiên vấn đề lại là, nếu các bản mạch \r\nchủ và CPU không hỗ trợ nó, lắp ráp RAM ECC cũng không mang lại lợi ích \r\ngì.</p><p>Về lý thuyết, dòng CPU Ryzen của AMD cũng hỗ trợ ECC, dù không\r\n chính thức. Nhưng chính vì vậy, điều này cũng không có gì đảm bảo các \r\nnhà sản xuất các linh kiện khác, như bo mạch chủ, hoặc các nhà OEM sản \r\nxuất máy tính, hỗ trợ tính năng này – ngay cả khi họ đã tuyên bố như \r\nvậy. Cách duy nhất chắc chắn một bo mạch chủ Ryzen nào đó tương thích \r\nvới ECC là chạy một ứng dụng nào đó gây ra lỗi nhảy bit để kích hoạt \r\ntính năng đó.</p><p style=\"text-align: left;\">Một hy vọng khác với người\r\n dùng là RAM DDR5 đang bắt đầu ra mắt trong năm 2020. Bên cạnh các cải \r\ntiến về dung lượng, băng thông và sức mạnh, điều đáng chú ý là các mã tự\r\n sửa lỗi ECC sẽ được nhúng ngay trong chip nhớ. Khi đó, sự phổ biến của \r\nthế hệ RAM mới này có thể sẽ kéo theo sự hỗ trợ rộng rãi hơn từ các linh\r\n kiện khác như bo mạch chủ.</p><p style=\"text-align: right;\"><i>Tham khảo ArsTechnica</i></p>', 'Cha đẻ Linux, Intel, linh kiện máy tính, ram ecc', NULL, 1, 'Linus-Torvalds.jpg', '2021-01-14 09:06:56', '2021-01-13 09:29:25', 1, 1),
(25, 5, 'Jack Ma thu về số tiền gấp 8 lần Amazon, Walmart, eBay cộng lại chỉ trong 1 ngày', 'jack-ma-thu-ve-so-tien-gap-8-lan-amazon-walmart-ebay-cong-lai-chi-trong-1-ngay', 'Lễ Độc Thân năm nay, Alibaba - thương hiệu mua sắm trực tuyến lớn nhất Trung Quốc đã phá kỉ lục của chính họ khi thu về tới 17,7 tỉ USD chỉ trong 1 ngày giảm giá - gấp gần 8 lần ngày Black Friday 2016 tại Mỹ.', '<h1 class=\"kbwc-title clearfix\">Nhờ bỏ ra 1 tỷ USD đầu tư công nghệ này,\r\n Jack Ma thu về số tiền gấp 8 lần Amazon, Walmart, Target hay eBay cộng \r\nlại chỉ trong 1 ngày</h1><div><p>Ngày hôm đó, toàn bộ nhân viên nhân viên kĩ thuật được điều động tập \r\ntrung ở một phòng để kiểm soát hàng triệu người dùng liên tục truy cập \r\nvào hệ thống mua sắm.</p>\r\n\r\n<p><i>\"Đó giống như 1 buổi diễu hành hay tập trận vậy\"</i>, Yunfei - Giám đốc sản phẩm của Alibaba Cloud miêu tả trụ sở làm việc ngày 11/11.</p>\r\n\r\n<p>Ban đầu, ngày 11/11 ở Trung Quốc cũng chỉ là một ngày tượng trưng cho\r\n những người độc thân, nhưng sau này đã trở thành ngày hội mua sắm của \r\ntoàn dân nước này.</p>\r\n\r\n<p>Tương tự như Black Friday và Cyber Monday, ngày này được coi như 1 lễ\r\n lớn trong năm. Với những mặt hàng giảm giá, người tiêu dùng Trung Quốc \r\ncó thể lựa chọn và sắm sửa những vật dụng cần thiết, chuẩn bị cho ngày \r\nTết truyền thống.</p>\r\n\r\n<p>Ông Yunfei chia sẻ:</p>\r\n\r\n<p><i>\"Quang cảnh năm nay khác hẳn mọi năm, đặc biệt là với chúng tôi, \r\nnhững người chỉ quan sát từ camera. Mặc dù là nửa đêm, nhưng ngay khi mở\r\n cửa vào đón khách, hàng nghìn lượt khách đã đua nhau chen chúc.</i></p>\r\n\r\n<p><i>Chúng tôi chẳng biết làm gì ngoài ăn mừng và vỗ tay. Chưa kịp ăn \r\nmừng xong thì doanh số bán hàng đã đạt 1 tỷ nhân dân tệ (tương đương 145\r\n nghìn USD). Chúng tôi còn không thể tin nổi kết quả đó!\".</i></p>\r\n\r\n<p>Yunfei cho biết, vào thời gian cao điểm của ngày Lễ độc thân năm nay,\r\n cơ sở dữ liệu ghi nhận có tới 175.000 giao dịch và 120.000 thanh toán \r\ncùng lúc chỉ trong 1 giây.</p>\r\n\r\n<p><i>\"Nhờ những ngày này mà chúng tôi có cơ hội nghiêm túc huấn luyện \r\ncho các kĩ sư ở đây. Qua đó, ngày càng nâng cao khả năng của họ, hướng \r\ntới phục vụ những thị trường lớn hơn ngoài Trung Quốc\".</i></p>\r\n\r\n<div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\">\r\n<div style=\"position: relative; display: inline-block;\"><a href=\"https://genk.mediacdn.vn/2016/photo-0-1480911684824.jpg\" data-fancybox-group=\"img-lightbox\" title=\"\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img alt=\"\" id=\"img_4df85f10-baa2-11e6-bee9-8ba0eb6afe81\" src=\"https://genk.mediacdn.vn/thumb_w/640/2016/photo-0-1480911684824.jpg\" rel=\"https://genk.mediacdn.vn/2016/photo-0-1480911684824.jpg\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/2016/photo-0-1480911684824.jpg\" class=\"lightbox-content\" style=\"margin-top: 137px; padding-top: unset;\"></a></div>\r\n\r\n\r\n</div>\r\n\r\n<p><span class=\"IMSNoChangeStyle\" style=\"font-size:20px;\"><strong style=\"font-size: 12.8pt;\">Khả năng tự cung tự cấp</strong></span></p>\r\n\r\n<p>Không ít người đặt ra câu hỏi: tại sao Alibaba Cloud - công nghệ được\r\n đầu tư 1 tỷ USD, có thể kết thúc ngày Lễ độc thân với chiến thắng vang \r\ndội như thế?</p>\r\n\r\n<p>Yunfei giải thích về hệ thống trơn tru của Alibaba Cloud: <i>\"Trên \r\ncác đám mây dự trữ nói chung, có rất nhiều công cụ cần phải xử lí. Điều \r\nkhác biệt lớn nhất chúng tôi có thể mang đến đó là chúng tôi tự tạo nên \r\ncác công cụ hỗ trợ cho hệ thống, vì vậy chúng tôi kiểm soát chúng vô \r\ncùng dễ dàng\".</i></p>\r\n\r\n<div id=\"admzone480457\"><div id=\"zone-480457\"><div id=\"share-jny27esn\"><div id=\"placement-khfyn14b\"><div id=\"banner-480457-khfyn14l\" style=\"min-height: 0px; min-width: 0px;\"><div id=\"slot-1-480457-khfyn14l\">\r\n</div></div></div></div> </div></div><p>Bằng cách chia nhỏ và lọc người \r\ndùng theo những thông tin định vị, mỗi khách hàng truy cập vào Alibaba \r\nđều sẽ nhận được luồng thông tin nhanh nhất từ cơ sở dữ liệu gần nhất. \r\nDo đó, hệ thống Alibaba không bị nghẽn mạng hay treo do có quá nhiều \r\ntruy cập cùng lúc.</p>\r\n\r\n<p>Được biết, có tới 10.000 máy chủ chạy cùng lúc ở hệ thống này, với lưu lượng thông tin 1 tỷ Gb.</p>\r\n\r\n<p>Không riêng gì phần mềm, Alibaba còn tự thiết kế phần cứng với những \r\nđối tác nổi tiếng như AMD với các sản phẩm chip đồ họa, và mới đây là \r\nhợp đồng với NVIDA chế tác AliCloud HPC, một công cụ tăng tốc GPU.</p>\r\n\r\n<p>MaxCompute, công ty xử lý dữ liệu cho Alibaba cũng xác nhận đã hoàn \r\nthành 1,98 triệu tác vụ chỉ trong ngày 11/11. 180 petabytes dữ liệu được\r\n chuyển đi từ 54.000 máy tính tại 7 trung tâm dữ liệu.</p>\r\n\r\n<p><i>\"Nếu chúng tôi không thể tự xây dựng hệ thống, những điều đó khó có thể xảy ra\"</i>, Yunfei cũng đưa ra nhận xét về những con số.</p>\r\n\r\n<div class=\"VCSortableInPreviewMode\" type=\"Photo\" style=\"width: 640px;\">\r\n<div><a href=\"https://genk.mediacdn.vn/2016/photo-1-1480911684826.jpg\" data-fancybox-group=\"img-lightbox\" title=\"\" target=\"_blank\" class=\"detail-img-lightbox\" style=\"color: rgb(84, 84, 84);\"><img alt=\"\" id=\"img_4dda9de0-baa2-11e6-bee9-8ba0eb6afe81\" src=\"https://genk.mediacdn.vn/thumb_w/640/2016/photo-1-1480911684826.jpg\" rel=\"https://genk.mediacdn.vn/2016/photo-1-1480911684826.jpg\" type=\"photo\" data-original=\"https://genk.mediacdn.vn/2016/photo-1-1480911684826.jpg\" class=\"lightbox-content\"></a></div>\r\n\r\n\r\n</div>\r\n\r\n<p><span class=\"IMSNoChangeStyle\" style=\"font-size:20px;\"><strong>Tầm nhìn</strong></span></p>\r\n\r\n<p>Yunfei và nhóm của ông đã chuẩn bị cho ngày Lễ Độc Thân từ hơn 6 \r\ntháng trước. Họ lên kế hoạch, xây dựng công nghệ dựa vào những dự đoán \r\nsự phát triển thị trường và đặt ra dự tính về những con số.</p>\r\n\r\n<p><i>\"Tới khi chúng tôi hoàn thiện hệ thống, chúng tôi sẽ sử dụng những con số dự tính làm mục tiêu ban đầu\"</i>, Yunfei chia sẻ.</p>\r\n\r\n<p>Nhưng những ước tính thì không thể chính xác hoàn toàn. Do đó, họ \r\ncùng nhau đưa ra các phương án để giải quyết tình huống, cũng như tự tạo\r\n tình huống để thử giải quyết.</p>\r\n\r\n<p><i>\"Các đồng nghiệp của tôi đã rất vất vả, mỗi ngày họ đều làm việc \r\ndưới áp lực rất lớn để mô phỏng ngày Lễ Độc Thân. Nhờ vậy mà chúng tôi \r\nmới tìm ra được các phương án giải quyết tốt hơn\",</i> Yunfei đầy tự hào khi nói về các đồng nghiệp.</p>\r\n\r\n<p><i>\"Chúng tôi thường có câu nói đùa rằng, nếu chưa trải nghiệm ngày \r\nLễ Độc Thân bao giờ, các bạn chưa phải là một thành viên của Alibaba \r\nchính hiệu\".</i></p>\r\n\r\n<p style=\"text-align: right;\"><i>Theo Trí Thức Trẻ</i></p></div><div><br></div>', 'Jack Ma, alibaba đầu tư công nghệ', NULL, 1, 'alibaba-lai-to.webp', '2021-01-14 08:35:20', '2021-01-14 08:38:21', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phoneNumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_admin` int(11) DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `token`, `phoneNumber`, `userId`, `firstName`, `lastName`, `is_admin`, `google_id`, `provider_name`, `provider_id`, `avatar`, `userName`, `status`, `phone`, `remember_token`, `created_at`, `updated_at`, `template_id`) VALUES
(2, 'Bất Động sản SGD', 'canhoduclong@gmail.com', '2020-09-03 02:26:36', '$2y$10$S03khl7ZoqFFh5/vtWEjB.OewOJ7SbOIIeiTCBw4hOwg4YAlMjiSK', NULL, NULL, NULL, NULL, NULL, 1, NULL, 'google', '102862251836032704506', 'https://lh4.googleusercontent.com/-86r5BgPMQb8/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuck5GfznVbgVGQ-lR_79IPYmsR3E9g/photo.jpg', NULL, NULL, NULL, 'M54g9X8Qq1C7cnDKitSCxLhl5GCbTWDxenR2Huz26vTQS9JwP3iwzBIRko4x', '2020-09-03 02:26:36', '2020-09-21 19:34:04', NULL),
(3, 'Việt Nam Thương Hiệu', 'ceo.brandviet@gmail.com', '2020-09-03 02:30:08', '', NULL, NULL, NULL, NULL, NULL, 0, NULL, 'google', '104878262851144726387', 'https://lh3.googleusercontent.com/a-/AOh14GgcidyB60Rw7xyumSCm6rCbH68sJXy8MP16c9Y', NULL, NULL, NULL, 'HnPruH9TWD0CDGoEVasvaSU5BrPwZzMCxTc2Z4bYhscx7S872tEV3Wz7YG07', '2020-09-03 02:30:08', '2020-09-03 02:30:08', NULL),
(4, 'huy nguyen', 'eco.huyit@gmail.com', '2020-09-03 02:30:27', '', NULL, NULL, NULL, NULL, NULL, 0, NULL, 'google', '108463419690387837729', 'dimension.png', NULL, NULL, NULL, '8049p3QHTG4gHlVTUn7dV589uV7QZzPOSe55xziHEEsHKjQqr9aNeNJVFK7I', '2020-09-03 02:30:27', '2020-09-21 19:56:43', NULL),
(5, 'Phạm Thư', 'huy8@natrapha.com', NULL, '$2y$10$OLQxyoSmmSJyyrP0WAaIA.a3F9Xks8E.cCYfRG0D.JZkuxf.5eyzK', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Imh1eThAbmF0cmFwaGEuY29tIiwibmJmIjoxNjAwMzk3ODk2LCJleHAiOjE2MDEwMDI2OTYsImlhdCI6MTYwMDM5Nzg5Nn0.moNU9Rp17aU5FtGNoh4UXV89X0i8u5iBvF96bea9r-Q', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 't9M0aktbKJ6vpjhh13tuFmNwUoq1hqQD7n9sXMTMNsHXGWHmxupDAWVopW8H', '2020-09-17 19:48:51', '2020-09-17 19:58:15', NULL),
(6, 'NGUYÊN CÔNG THÀNH', 'hoalamreal@gmail.com', NULL, '$2y$10$oQrO8E3VQkELTs9z9yYp7OFQned4QBA.BzLAijtN7NXlhnDGuE.yy', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImhvYWxhbXJlYWxAZ21haWwuY29tIiwibmJmIjoxNjAxNDMwOTMxLCJleHAiOjE2MDIwMzU3MzEsImlhdCI6MTYwMTQzMDkzMX0.THAije1bWQK9koB-SrWw2xM3JhYBJgYZLEq0FBYwudc', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'dimension.png', NULL, NULL, NULL, 'yWU74Hz0M6qwWwXrbrxCQlxuqsssykcbx23Z4qtul1kpT2JG0fbrpKo2jF35', '2020-09-17 23:56:12', '2020-09-29 18:55:17', NULL),
(7, 'khachhang', 'canhomoi@gmail.com', NULL, '$2y$10$rlF1XnY.tKctjv1SlCFW.ebBH//qs2bjCC.L8W3sU.PQkA/Lpo5BK', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-18 22:09:41', '2020-09-18 22:09:41', NULL),
(8, 'nguyen huy', 'ketloc@gmail.com', NULL, '$2y$10$u0vN7aPAf1xtvnrimOJf8efZ2vCzEI7uIxhS.4J0j3ghPH0FuvEGK', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0G7bkA4isXIrSMAXVJsq3fd1Yk4keqpt1U2nnjbM4L6e4UAI4OCt1gQcz0Kz', '2020-09-23 01:09:11', '2020-09-23 01:09:11', NULL),
(9, 'nguyen cong danh', 'huy12@natrapha.com', NULL, '$2y$10$DqN8e8TdM7.5G3yvCBENh.UWzRgBdUJLbxVsINarOCsL.2m6gLNzS', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-23 18:47:27', '2020-09-23 18:47:27', NULL),
(10, 'thanh cong nhé ban nguyen nguyen', 'huy14@natrapha.com', NULL, '$2y$10$sAlHn2FXVjhVpmuqbwpQlubxERv2alJqCLKPC4wWwElOuiEQXQNzW', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Imh1eTE0QG5hdHJhcGhhLmNvbSIsIm5iZiI6MTYwMDkzMjMwNywiZXhwIjoxNjAxNTM3MTA3LCJpYXQiOjE2MDA5MzIzMDd9.UdH-7P-h95OO-x6nVW3z844R0qoFA5VGFWBdRLMS71A', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'li51f8uBG3ssp9umelONhocvO2iHFyWCyBnJL1WfqoVPOorsFp0uvP0ofe9V', '2020-09-23 19:59:24', '2020-09-24 00:24:57', NULL),
(11, 'hoang ha nam', 'huy11@natrapha.com', NULL, '$2y$10$OV.vUMRUWjZp4vvNEIgRfOHFJEEWoIPBGvjiA1hjSVpE909IsBRsm', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'rtQUoa7zzi17ErK6qBoD43wG3SxBbm92eymJ12sJUUkSaZjEYm8Tu4YQrB8T', '2020-09-24 02:25:06', '2020-09-24 02:25:06', NULL),
(12, 'huy', 'canhoduclongs@gmail.com', NULL, '$2y$10$uIpW7tJXS05zpIQqEIqfFu1cMdvrZPuXU6I/eAWjFw/hmATgboQXq', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-04 08:17:35', '2021-01-04 08:17:35', NULL),
(13, 'Khắc Hiếu Huỳnh', 'khachieudn@gmail.com', '2021-01-06 21:05:47', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'google', '104435659044042653106', 'https://lh3.googleusercontent.com/a-/AOh14Gid5mn0ApVMDjaT46EzgPpBsm7EzHFrD1NHAO79=s96-c', NULL, NULL, NULL, 'KHzwDdZr0HN4bVpRFjpqfwHcQd3gszYA8diSZ44jUtWfIN14i0wzVINMtJDE', '2021-01-06 21:05:47', '2021-01-06 21:05:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `src` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desription` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyword` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_detail`
--
ALTER TABLE `orders_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `template`
--
ALTER TABLE `template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `orders_detail`
--
ALTER TABLE `orders_detail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photo`
--
ALTER TABLE `photo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `template`
--
ALTER TABLE `template`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
